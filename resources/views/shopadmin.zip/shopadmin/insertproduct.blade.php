@extends('layouts.app')
@section('stylesheet')
        <!-- DataTables CSS -->
    <link href="{{ asset('plugins/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css') }}" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="{{ asset('plugins/datatables-responsive/css/dataTables.responsive.css') }}" rel="stylesheet">
@endsection
@section('content')
 <section class="content">
    <div class="box box-default">
        <div class="box-header with-border">
            <h3 class="box-title">Create New Product</h3>
            <div class="box-tools pull-right">
            <a href="{{ url('/shop') }}" class="btn btn-danger"><i class="fa fa-home"></i>&nbsp;User Shop</a>
            <a href="{{ url('/adminshop') }}" class="btn btn-danger"><i class="fa fa-home"></i>&nbsp;Admin Store</a>
            </div>
        </div><!-- /.box-header -->
        <div class="box-body">

        <div class="col-md-12 pull-right"></div>

           <form class="form-horizontal" method="post"  enctype="multipart/form-data" action="{{ url('/insertproduct') }}">
                                
                <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-name1">Change Category</label>
                    <div class="col-sm-10">
                      <select name="categoryID" id="categoryID" onselect="getSubCategory()" onchange="getSubCategory()" class="form-control">
                        @foreach ($category as $cat)
                          <option value="{!! $cat->id !!}">{!! $cat->cat_name !!}</option>
                        @endforeach
                      </select>
                    </div>
                  </div>

                <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-name1">Change Sub Category</label>
                    <div class="col-sm-10">
                    
                      <select name="subCategoryID" id="subCategoryID" class="form-control">
                      </select>
                    </div>
                  </div>

              <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-name1">Product Name</label>
                    <div class="col-sm-10">
                      <input type="text" name="item_name" value="" placeholder="Product Name" id="input-name1" class="form-control" />
                                          </div>
                  </div>
                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-name1">Brand Name</label>
                    <div class="col-sm-10">
                      <input type="text" name="brand_name" value="" placeholder="Brand Name" id="input-name1" class="form-control" />
                                          </div>
                  </div>
                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-name1">SKU</label>
                    <div class="col-sm-10">
                      <input type="text" name="sku" value="" placeholder="SKU" id="input-name1" class="form-control" />
                                          </div>
                  </div>
                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-name1">Quantity</label>
                    <div class="col-sm-10">
                      <input type="text" name="quantity" value="" placeholder="Quantity" id="input-name1" class="form-control" />
                                          </div>
                  </div>
                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-name1">Price</label>
                    <div class="col-sm-10">
                      <input type="text" name="price" value="" placeholder="Price" id="input-name1" class="form-control" />
                                          </div>
                  </div>


                  <div class="form-group">
                    <label class="col-sm-2 control-label" for="input-description1">Description</label>
                    <div class="col-sm-10">
                      <textarea name="product_description" placeholder="Description" id="input-description1" class="form-control summernote"></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label" for="input-tag1">Product Image</label>
                    <div class="col-sm-10">
                      <input type="file"  accept="image/png, image/jpeg" name="product_image" placeholder="Product Image" id="input-tag1" class="form-control" />
                    </div>
                  </div>
                  <div class="form-group required">
                    <label class="col-sm-2 control-label" for="input-meta-title1">Meta Tag Title</label>
                    <div class="col-sm-10">
                      <input type="text" name="product_meta_title" value="" placeholder="Meta Tag Title" id="input-meta-title1" class="form-control" />
                                          </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label" for="input-meta-description1">Meta Tag Description</label>
                    <div class="col-sm-10">
                      <textarea name="product_meta_description" rows="5" placeholder="Meta Tag Description" id="input-meta-description1" class="form-control"></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2 control-label" for="input-meta-keyword1">Meta Tag Keywords</label>
                    <div class="col-sm-10">
                      <textarea name="product_meta_keyword" rows="5" placeholder="Meta Tag Keywords" id="input-meta-keyword1" class="form-control"></textarea>
                    </div>
                  </div>
{{--                   <div class="form-group">
                    <label class="col-sm-2 control-label" for="input-tag1"><span data-toggle="tooltip" title="Comma separated">Product Tags</span></label>
                    <div class="col-sm-10">
                      <input type="text" name="product_tag" value="" placeholder="Product Tags" id="input-tag1" class="form-control" />
                    </div>
                  </div> --}}

                  <div class="form-group">
                    <div class="col-md-2"></div>
                    <div class="col-md-10 ">
                    <button type="submit" class="btn btn-success clear-fix" >Submit</button>
                    </div>
                   
                  </div>

</form>

          
        </div>
   
</section>

@endsection
@section('scripts')
<script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('plugins/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js') }}"></script>
<script>
    $(document).ready(function () {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    $(document).ready(function () {
        $('#dataTables-example1').DataTable({
            responsive: true
        });
    });

    //Get Sub Category By CategoryID
    var subcategories= <?= $subcategory; ?>;

    function subcategory() {
      //Get the ID of the current Selected Option
      var e = document.getElementById("categoryID");
      var currentCatID = e.options[e.selectedIndex].value;

      var replyVal = "";

      for (var i =0; i < subcategories.length; i++) {
        if(subcategories[i].cat_id == currentCatID) {
          $("#subCategoryID").append("<option value='"+ subcategories[i].id +"'>" + subcategories[i].sub_catname + "</option>");
        }
      }
    }

    function removeOptions(selectbox)
    {
        var i;
        for(i = selectbox.options.length - 1 ; i >= 0 ; i--)
        {
            selectbox.remove(i);
        }
    }

    function getSubCategory() {
      removeOptions(document.getElementById("subCategoryID"));
      subcategory();
    }

    $(document).ready(function () {
        getSubCategory();
    });
</script>

@endsection                   
