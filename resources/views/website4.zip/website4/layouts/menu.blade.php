    <nav class="navbar navbar-static-top yamm ms-navbar ms-navbar-primary">
        <div class="container container-full">
            <div class="navbar-header" style="    width: 22%;">

                <a  href="/">
                    <img class="hidden-xs" style="width: 62%; padding-left:10%" src="{{asset('/public/assets/website4/front/img/demo/logo-navbar.png')}}" alt="">
                    {{--<span class="ms-logo ms-logo-sm">M</span>--}}
                    {{--<span class="ms-title">Material--}}
                {{--<strong>Style</strong>--}}
              {{--</span>--}}
                </a>
            </div>
            <span style="position: fixed; left: 150px; top: 1%; " class="visible-xs">

                @if (Auth::check())

                <a href="{{url('/home')}}">

                <div style="width: 40px; height: 40px; border: 1px solid #fff; border-radius: 50%; text-align: center;"><i class="fa fa-user" id="logged-in" style="font-size:30px; color:#00FF00; padding-top: 5px;"></i>

                </div>
                </a>
                @endif

                <div class="dd" style="display: none;">
                    <ul class="nav navbar-nav navbar-right" style="background: #FF5722;">
                    <!-- Authentication Links -->
                    @if (Auth::guest())
                        <li><a href="{{ url('/login') }}">Login</a></li>
                        <li><a href="{{ url('/join-now') }}">Join Now</a></li>
                    @else
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                {{ Auth::user()->name }} <!-- <span class="caret"></span> -->
                            </a>

                            <ul class="dropdown-menu" role="menu">
                                <li>
                                    <a href="{{ url('/logout') }}">
                                        Logout
                                    </a>

                                </li>
                                <li><a href="{{ url('/home') }}">Back Office</a></li>
                            </ul>
                        </li>
                    @endif
                    </ul>
                </div>
                </span>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav">
                    <li class="dropdown active">
                        <a href="{{ url('/') }}">Home

                        </a>

                    </li>
                    <li class="dropdown">
                        <a href="{{ url('/about-us') }}">About Us

                        </a>

                    </li>
                    <li class="dropdown yamm-fw">
                        <a href="{{ url('/') }}/#Compensation">Compensation Plan
                        </a>
                    </li>
                    <li class="dropdown">
                        <a href="https://www.blog.happyworldmealgate.org" >Blog
                        </a>

                    </li>
                  <!--   <li class="dropdown">
                        <a href="/gallery" >Gallery

                        </a>

                    </li> -->
                    <li class="dropdown">
                        <a href="{{ url('/contact') }}" >Contact</a>

                    </li>
                    <li class="dropdown">
                        <a href="{{ url('/faq') }}" >FAQ </a>

                    </li>
                    <li class="dropdown">
                        <a href="{{ url('/login') }}">Login</a>

                    </li>
                    <li class="dropdown">
                        <a href="{{ url('/join-now') }}">Join Now</a>

                    </li>
                    {{--<li class="btn-navbar-menu" style="color: #ff7722" ><a href="javascript:void(0)" class="sb-toggle-left"><i class="zmdi zmdi-menu"></i></a></li>--}}
                </ul>
            </div>
            <!-- navbar-collapse collapse -->
            <a style="color: #ff7722" href="javascript:void(0)" class="sb-toggle-left btn-navbar-menu">
                <i class="zmdi zmdi-menu"></i>
            </a>
        </div>
        <!-- container -->
    </nav>
