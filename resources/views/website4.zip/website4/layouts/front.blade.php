<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#333">
    <title>Happy World Meal Gate</title>
    <meta name="description" content="Happy World Meal Gate is a passionate and dynamic Multi Level Marketing (MLM) company of African extraction on a mission to bring smiles to peoples faces.
We strongly believe hunger and malnutrition are a global threat and a monstrous emergency which must be tackled decisively and without delay">

    <link rel="shortcut icon" href="{{asset('public/assets/website4/front/img/favicon30f4.png?v=3')}}">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons')}}">
    <link rel="stylesheet" href="{{asset('public/assets/website4/front/css/preload.min.css')}}" />
    <link rel="stylesheet" href="{{asset('public/assets/website4/front/css/plugins.min.css')}}" />
    <link rel="stylesheet" href="{{asset('public/assets/website4/front/css/style.light-blue-500.min.css')}}" />
    <link rel="stylesheet" href="{{asset('public/assets/website4/front/css/width-boxed.min.css')}}" id="ms-boxed" disabled="">
    <link href="https://fonts.googleapis.com/css?family=Karla:400,700" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="{{asset('front/js/html5shiv.min.js')}}"></script>
    <script src="{{asset('front/js/respond.min.js')}}"></script>
    <![endif]-->
    
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-145464205-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-145464205-1');
</script>

</head>
<body>

<div class="scrollbar" id="style-1">
    <div class="force-overflow"></div>
</div>

<div id="ms-preload" class="ms-preload">
    <div id="status">
        <div class="spinner">
            <div class="dot1"></div>
            <div class="dot2"></div>
        </div>
    </div>
</div>

<div class="sb-site-container">


@include('website4.layouts.menu')

@yield('content')
    <footer class="ms-footer">
        <div class="container">
            <p>Copyright &copy; Happy World Meal Gate <?php echo date('Y') ?><button type="button" onclick="payWithPaystack()"> P </button></p>
        </div>
    </footer>
    <div class="btn-back-top">
        <a href="#" data-scroll id="back-top" class="btn-circle btn-circle-primary btn-circle-sm btn-circle-raised ">
            <i class="zmdi zmdi-long-arrow-up"></i>
        </a>
    </div>
</div>
<!-- sb-site-container -->

@include('website4.layouts.sidebar')
<div class="modal modal-warning" id="modal" style="padding-top: 7%;" tabindex="-1" role="dialog" aria-labelledby="myModalLabel6">
    <div class="modal-dialog animated zoomIn animated-3x" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="zmdi zmdi-close"></i></span></button>
                <h3 class="modal-title" id="myModalLabel6">Notifications</h3>
            </div>
           
                <div class="modal-body">
               <!-- <p>The food portal is open for ordering from Sunday, 28th July 2019 till monday 29th July 2019 (12 noon).</p>-->
               
              <a style="color:black" href="http://blog.happyworldmealgate.org"> The portal is open for food ordering from Friday 30/8/19 till Sunday 1/9/19(5pm).</a>
               
               <!-- <a style="color:black" href="http://blog.happyworldmealgate.org"> <p>The portal opening has been extended to tuesday 30/7/19 (2pm). Moreso, our team is working at resolving the recent challenges members ecountered while placing their food orders.</p> <button class="btn btn-info">click here for more info</button></a>-->
                
                
                
                
                <p><span style="font-family: Calibri; font-size: 14.0000pt;">NOTICE OF HAPPY WORLD&rsquo;S 3RD</span><span style="font-family: Calibri; font-size: 14.0000pt;">&nbsp;ANNIVERSARY/CAR AWARDS &nbsp;&amp; REMOVAL OF MONTHLY SURCHARGE</span></p>
<p><span style="font-family: Calibri; font-size: 14.0000pt;">The Management of Happy World Meal Gate wishes to notify its teeming members that its 3rd</span><span style="font-family: Calibri; font-size: 14.0000pt;">&nbsp;anniversary celebration will hold on 26</span><sup><span style="font-family: Calibri; font-size: 14.0000pt; vertical-align: super;">th</span></sup><span style="font-family: Calibri; font-size: 14.0000pt;">&nbsp;October in Lagos, Nigeria.</span></p>
<p><span style="font-family: Calibri; font-size: 14.0000pt;">The forthcoming anniversary will be merged with the Car Awards presentation to deserving Stage 4 Awardees. To ensure a historic and hitch-free event, a high-powered committee has been handed the arduous task of making this highly anticipated event a reality.</span></p>
<p><span style="font-family: Calibri; font-size: 14.0000pt;">This notice enables members who are on the verge of circling into Stage 4, ample time to do so and will significantly increase the number of awardees that will be honored in October 2019.More details will be released shortly.</span></p>
<p><span style="font-family: Calibri; font-size: 14.0000pt;">Finally, as a customer-focused company with service delivery in mind, Management has forthwith removed the $2 surcharge which was deducted monthly from all Happy World accounts. Henceforth, $0.5 will be deducted from every transaction on the Basic Package, while $1 will be deducted from every transaction on Premium Package.</span></p>
<p><span style="font-family: Calibri; font-size: 14.0000pt;">While We continually appreciate your co-operation, be rest assured of our commitment and adherence to global best practices.</span></p>
<p><span style="font-family: Calibri; font-size: 14.0000pt;">&nbsp;</span></p>
<p><span style="font-family: Calibri; font-size: 14.0000pt;">Signed</span></p>
<p><span style="font-family: Calibri; font-size: 14.0000pt;">Management</span></p>
                
                
                
                
                
                
               <img src="{{ asset('images/WhatsApp Image 2019-07-15 at 5.30.02 PM.jpeg') }}" class="" style="height:100%; width:100%" alt="">
               
           

               <a href="http://blog.happyworldmealgate.org" class="btn btn-danger">Click here for more</a>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script src="{{asset('public/assets/website4/front/js/plugins.min.js')}}"></script>
<script src="{{asset('public/assets/website4/front/js/app.min.js')}}"></script>
<script src="{{asset('public/assets/website4/front/js/configurator.min.js')}}"></script>
<script src="{{asset('public/assets/website4/front/js/portfolio.js')}}"></script>
<script src="https://js.paystack.co/v1/inline.js"></script>
<script>
  function payWithPaystack(){
    var email = window.prompt("Please enter a valid email address");

    if(!validateEmail(email)){
        alert("Please enter a valid email");
        return;
    }

    var numberOfPins = window.prompt("How many Pins");

    if(!validateNumber(numberOfPins)){
        alert("Please enter a valid number");
        return;
    }


    var handler = PaystackPop.setup({
      key: 'pk_test_afab22d5427c2714c8b492a8fc39cde5b135994d',
      email: email,
      amount: 1000000 * numberOfPins,
      currency: "NGN",
      ref: ''+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
      metadata: {
         custom_fields: [
            {
                display_name: "Mobile Number",
                variable_name: "mobile_number",
                value: "+2348012345678"
            }
         ]
      },
      callback: function(response){
          alert('success. transaction ref is ' + response.reference);
          onlinePinGenerator(numberOfPins, email);
            // Generate the number of pins for the user
      },
      onClose: function(){
          alert('window closed');
      }
    });
    handler.openIframe();
  }

  function validateEmail(email)
    {
        var re = /\S+@\S+\.\S+/;
        return re.test(email);
    }


    function validateNumber(number) {
        var n = Math.floor(Number(number));
        return n !== Infinity && String(n) === number && n > 0;
    }

    function onlinePinGenerator(number, email) {
      $.ajax({
      url: '{{ url("/")}}/online-pin-generator',
      type: 'post',
      data:
      {
          "_token": "{{ csrf_token() }}"
      },
      dataType: 'json',
      success: function(data) {
          console.log(data);
      },
      error: function(xhr, ajaxOptions, thrownError) {
        alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
      }
    });
  }
</script>
<script type="text/javascript">
    $(window).on('load',function(){
        $('#modal').modal('show');
    });
</script>

@yield('scripts')
</body>
</html>