<div class="ms-slidebar sb-slidebar sb-left sb-momentum-scrolling sb-style-overlay">
    <header class="ms-slidebar-header">
        {{--<div class="ms-slidebar-login">--}}
            {{--<a href="javascript:void(0)" class="withripple">--}}
                {{--<i class="zmdi zmdi-account"></i> Login</a>--}}
            {{--<a href="javascript:void(0)" class="withripple">--}}
                {{--<i class="zmdi zmdi-account-add"></i> Register</a>--}}
        {{--</div>--}}

    </header>
    <ul class="ms-slidebar-menu" id="slidebar-menu" role="tablist" aria-multiselectable="true">

        <li class="panel" role="tab" id="sch1">
            <a class="collapsed" role="button" data-toggle="collapse"  href="{{ url('/') }}" aria-expanded="false" aria-controls="sc1">
                <i class="zmdi zmdi-home"></i> Home </a>

        </li>
        <li class="panel" role="tab" id="sch2">
            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#slidebar-menu" href="{{ url('/about-us') }}" aria-expanded="false" aria-controls="sc2">
                <i class="zmdi zmdi-desktop-mac"></i> About Us </a>

        </li>
        <li class="panel" role="tab" id="sch4">
            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#slidebar-menu" href="{{ url('/') }}/#Compensation" aria-expanded="false" aria-controls="sc4">
                <i class="zmdi zmdi-edit"></i> Compensation Plan </a>

        </li>
        <li class="panel" role="tab" id="sch5">
            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#slidebar-menu" href="#" aria-expanded="false" aria-controls="sc5">
                <i class="zmdi zmdi-shopping-basket"></i> Blog </a>

        </li>
        <li class="panel" role="tab" id="sch6">
            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#slidebar-menu" href="/gallery" aria-expanded="false" aria-controls="sc6">
                <i class="zmdi zmdi-collection-image-o"></i> Gallery </a>

        </li>
        <li>
            <a class="/faq" href="{{ url('/login') }}">
                <i class="zmdi zmdi-view-compact"></i> Login</a>
        </li>
        <li>
            <a class="/faq" href="{{ url('/join-now') }}">
                <i class="zmdi zmdi-view-compact"></i> Join Now</a>
        </li>

    </ul>

</div>
