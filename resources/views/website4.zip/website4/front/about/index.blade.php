@extends('website4.layouts.front')
@section('content')
    <div class="ms-hero-page ms-hero-img-coffee ms-hero-bg-success mb-6">
        <div class="container">
            <div class="text-center">
                <h1 class="no-m ms-site-title color-white center-block ms-site-title-lg mt-2 animated zoomInDown animation-delay-5">About Us</h1>
                <!-- <p class="lead lead-lg color-white text-center center-block mt-2 mb-4 mw-800 text-uppercase fw-300 animated fadeInUp animation-delay-7">Feel free to contact us at any of our office closest to you</p> -->

            </div>
        </div>
    </div>
    <div class="container">
        <p>The founder of Happy World Meal Gate is not a stranger to hunger-he grew up in the midst of it.He knows the pain and hopelessness associated with hunger and malnutrition.He has been there!He grew up as a farm boy in a remote area of Nigeria and had to put up with a lot of deprivations.As providence would have it,he struggled through the daunting challenges ,got sound education and earned a comfortable economic status.But he wasn&rsquo;t satisfied.He was worried about the global threat posed by hunger and malnutrition especially in Africa where over 27% of the population is under the scourge of severe food insecurity.</p>
        <p>He decided to embark on a mission to wrestle the debilitating cycle of hunger to the ground.He got thinking and came up with the concept of creating a platform for sustainable food/reward system that will not only afford participants food supply but economic buoyancy.Happy World Meal Gate is a multi-level marketing (MLM) network that was started in 2016 to help people overcome hunger and poverty.As a confirmation that the right chord had been struck,the concept very quickly attracted a huge number of participants from all walks of life-civil servants,traders,artisans,pensioners,farmers,students and other low income earners-whose fortunes have now taken an upward swing.</p>
        <p>Today,Happy World Meal Gate has metamorphosed into a movement that has rapidly spread its tentacles to all parts of Nigeria and several African countries with membership in excess of 2 million.Beyond the multilevel marketing aspect of HWMG&rsquo;s operation,the organization is partnering with governments and corporate institutions to enhance agricultural productivity and combat hunger in Africa.It encourages economic development in every country where it operates by distributing only food items produced in that country.</p>
        <p>The rapid success of HWMG as pioneers in this realm has brought about the emergence of a flood of business &nbsp;copycats that have unsuccessfully tried to imitate its model.HWMG&rsquo;s superiority is anchored on originality,integrity and robust corporate governance.HWMG has assembled a crop of bright minded and dedicated personnel who are consummate believers in the fight against hunger,malnutrition and poverty and are prepared to help you in your quest for food sufficiency and financial freedom.</p>
        <p>Join the movement.</p>
    </div>
    @endsection
