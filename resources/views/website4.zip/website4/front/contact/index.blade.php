@extends('website4.layouts.front')
@section('content')
    <div class="ms-hero-page ms-hero-img-coffee ms-hero-bg-success mb-6">
        <div class="container">
            <div class="text-center">
                <h1 class="no-m ms-site-title color-white center-block ms-site-title-lg mt-2 animated zoomInDown animation-delay-5">Contact Addresses</h1>
                <p class="lead lead-lg color-white text-center center-block mt-2 mb-4 mw-800 text-uppercase fw-300 animated fadeInUp animation-delay-7">Feel free to contact us at any of our office closest to you</p>

            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">

            <div class="col-md-4">
                <div class="card card-danger">
                    <div class="card-header"><h3 class="card-title"> HEAD Office (Lagos)</h3></div><div class="card-block">
                        <!-- <iframe src="https://www.google.com/maps/embed?pb=!4v1551710868886!6m8!1m7!1skd4TDU-JrUbaoUJrp70W_A!2m2!1d6.619152783958447!2d3.336872792105719!3f346.9865406916336!4f-5.7268141338861795!5f0.7820865974627469" width="100%" height="272" frameborder="0" style="border:0" allowfullscreen></iframe> -->
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3963.221572067121!2d3.3348820147712015!3d6.619373595213308!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x103b93d3b9ce4beb%3A0x76f4970eec75d5f9!2sHappy+World+Meal+Gate!5e0!3m2!1sen!2sng!4v1551794979143" width="100%" height="272" frameborder="0" style="border:0" allowfullscreen></iframe>
                        <hr>
                        <p><b>Address: </b> Cocoa Industries Ltd Complex, No 1 Cocoa Industries Road, off Akilo Road, Ogba-Ikeja, Lagos State<br>
                          <b>Phones</b> 08091830700,08110020644
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-danger">
                     <div class="card-header"><h3 class="card-title"> KADUNA Office</h3></div><div class="card-block">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3922.995584414482!2d7.4222826490666325!3d10.501013292472017!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x104d356e4cfc5b87%3A0x3199ac375b93ca83!2sHappy+World+Meal+Gate+Kaduna!5e0!3m2!1sen!2sng!4v1521116201272" width="100%" height="272" frameborder="0" style="border:0" allowfullscreen></iframe>
                        <hr>
                        <p><b>Address: </b>Matz Plaza,opp Ahmadu Bello Stadium, Kaduna</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-danger">
                     <div class="card-header"><h3 class="card-title">ABUJA Office</h3></div><div class="card-block">
                         <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d989.8575697536376!2d7.4301926794440005!3d9.065488935693185!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sAlba+Plaza+opp+Busy+Mart%2CJabi+District+Abuja!5e0!3m2!1sen!2sng!4v1523290276679" width="100%" height="272" frameborder="0" style="border:0" allowfullscreen></iframe>\
                         <hr>
                        <p><b>Address: </b>1st Floor,Alba Plaza opp Busy Mart,Jabi District, Abuja</p>
                    </div>
                </div>
            </div>
        </div>
            <div class="row">
            <div class="col-md-4">
                <div class="card card-danger">
                     <div class="card-header"><h3 class="card-title"> OYO Office </h3></div><div class="card-block">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3956.6855637921303!2d3.8794736911434806!3d7.38908831157391!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x10398d11fc1f174b%3A0x58308905f39c9f62!2sOxford+Building!5e0!3m2!1sen!2sng!4v1523290427121" width="100%" height="272" frameborder="0" style="border:0" allowfullscreen></iframe>
                        <hr>
                        <p><b>Address: </b>Oxford Building,Bank Way Opp Union Bank, Ibadan</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-danger">
                     <div class="card-header"><h3 class="card-title"> BENUE Office </h3></div><div class="card-block">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3953.6180893772334!2d8.54433106535286!3d7.724060322059813!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xcdabed9af3be5afd!2sVICTORIA+ATOROUGH+TYOUGH+COMPLEX!5e0!3m2!1sen!2sng!4v1523290711759" width="100%" height="272" frameborder="0" style="border:0" allowfullscreen></iframe>
                        <hr>
                        <p><b>Address: </b>Victoria Atorough Tyough Complex,No 6 New Bridge Road,Makurdi</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-danger">
                     <div class="card-header"><h3 class="card-title"> RIVERS Office</h3></div><div class="card-block">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3975.613774559928!2d6.988584048656929!3d4.836193596470952!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1069ce6ca83df455%3A0xe6d055a61b36b4b6!2s114+Rumuola+Rd%2C+Rumuchita+500272%2C+Port+Harcourt!5e0!3m2!1sen!2sng!4v1523290873011" width="100%" height="272" frameborder="0" style="border:0" allowfullscreen></iframe>
                        <hr>
                        <p><b>Address: </b>114 Rumuola Rd,Port Harcourt.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="card card-danger">
                     <div class="card-header"><h3 class="card-title"> Other Offices</h3></div><div class="card-block">
                        <p><b>Ghana</b>: Unique Estate Building Opposite Shell Petrol Station, Ajiringanor Block factory, Accra. <br> +233 5584 08214</p>
                         <p><b>Benin Republic</b>: Immeuble Carre LeEn Face
CEB Akossombo
<br> +229 9707 1581</p>
                          <p><b>Cameroon</b>: Orange Building (1st FLoor) Adjacent Carre Four Dernier Poteau Douala
 <br>+00237 650629978</p>
                    </div>
                </div>
            </div>
             <div class="col-md-4">
                <div class="card card-danger">
                     <div class="card-header"><h3 class="card-title">    Social Media Handles:</h3></div><div class="card-block">
                        <p><i class="color-danger-light zmdi zmdi-facebook mr-1"></i><b>Facebook</b>: <a href="https://www.facebook.com/happyworldmealgate">Happy World Meal Gate </a></p>
                         <p><i class="color-danger-light zmdi zmdi-twitter mr-1"></i><b>Twitter</b>: <a href="https://www.twitter.com/happyworldmeal">@happyworldmeal </a></p>
                          <p><i class="color-danger-light zmdi zmdi-instagram mr-1"></i><b>Instagram</b>: <a href="https://www.Instagram.com/happyworldmeal">@happyworldmealgate_Official</a></p>
                          <p><i class="color-danger-light zmdi zmdi-youtube mr-1"></i><b>YouTube</b>: <a href="https://www.youtube.com/channel/UCnZ0Dcq0yPblAzn0ASoRbQA/videos">HappyWorldMealGate Official</a></p>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
    @endsection
