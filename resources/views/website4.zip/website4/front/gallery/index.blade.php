@extends('website4.layouts.front')
@section('content')

      <div class="ms-hero-page ms-hero-img-coffee ms-hero-bg-success mb-6">
        <div class="container">
          <div class="text-center">
            <h1 class="no-m ms-site-title color-white center-block ms-site-title-lg mt-2 animated zoomInDown animation-delay-5">Portfolio</h1>
            <p class="lead lead-lg color-white text-center center-block mt-2 mb-4 mw-800 text-uppercase fw-300 animated fadeInUp animation-delay-7">Discover our projects and the
              <span class="color-warning">rigorous process</span> of creation. Our principles are creativity, design, experience and knowledge.</p>

          </div>
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-md-3 hidden-sm hidden-xs">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="zmdi zmdi-filter-list"></i>Filter List</h3>
              </div>
              <div class="card-block no-pb">
                <form class="form-horizontal">
                  <h4 class="no-m color-primary">Categories</h4>
                  <div class="form-group mt-1">
                    <div class="radio no-mb">
                      <label>
                        <input type="radio" name="optionsRadios" id="optionsRadios0" value="option0" checked="" class="filter" data-filter="all"> All </label>
                    </div>

                    @foreach($categories as $category)
                    <div class="radio no-mb">
                      <label>
                        <input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" class="filter" data-filter=".{{$category->name}}"> {{$category->name}} </label>
                    </div>

                      @endforeach
                  </div>
                </form>

              </div>

              <div class="card-block">
                <form class="form-horizontal">
                  <div class="form-group no-mt">
                    <div class="col-md-12">
                      <h4 class="no-m color-primary mb-2">Descriptions</h4>
                      <div class="togglebutton">
                        <label>
                          <input id="port-show" type="checkbox"> Show description </label>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div class="col-md-9">
            <div class="row" id="Container">
              @foreach($galleries as $gallery)
              <div class="col-md-4 col-sm-6 mix category-1 {{$gallery->categories->name}}">
                <div class="card">
                  <figure class="ms-thumbnail">
                    <img src="../image/{{$gallery->image}}"  alt="" class="img-responsive">
                    <figcaption class="ms-thumbnail-caption text-center">
                      <div class="ms-thumbnail-caption-content">
                        <h4 class="ms-thumbnail-caption-title mb-2">Lorem ipsum dolor</h4>
                        <a href="javascript:void(0)" class="btn-circle btn-circle-raised btn-circle-xs mr-1 btn-circle-white color-danger">
                          <i class="zmdi zmdi-favorite"></i>
                        </a>
                        <a href="javascript:void(0)" class="btn-circle btn-circle-raised btn-circle-xs ml-1 mr-1 btn-circle-white color-warning">
                          <i class="zmdi zmdi-star"></i>
                        </a>
                        <a href="javascript:void(0)" class="btn-circle btn-circle-raised btn-circle-xs ml-1 btn-circle-white color-success">
                          <i class="zmdi zmdi-share"></i>
                        </a>
                      </div>
                    </figcaption>
                  </figure>
                  <div class="card-block text-center portfolio-item-caption hidden">
                    <h3 class="color-primary no-mt">Lorem ipsum dolor</h3>
                    <p>Explicabo consequatur quidem praesentium quas qui eius ina Cupiditate ratione sint.</p>
                  </div>
                </div>
              </div>
              <!-- item -->
              @endforeach

            </div>
          </div>
        </div>
      </div>
      <!-- container -->


    </div>
    <!-- sb-site-container -->
    <div class="ms-slidebar sb-slidebar sb-left sb-momentum-scrolling sb-style-overlay">
      <header class="ms-slidebar-header">
        <div class="ms-slidebar-login">
          <a href="javascript:void(0)" class="withripple">
            <i class="zmdi zmdi-account"></i> Login</a>
          <a href="javascript:void(0)" class="withripple">
            <i class="zmdi zmdi-account-add"></i> Register</a>
        </div>
        <div class="ms-slidebar-title">
          <form class="search-form">
            <input id="search-box-slidebar" type="text" class="search-input" placeholder="Search..." name="q" />
            <label for="search-box-slidebar">
              <i class="zmdi zmdi-search"></i>
            </label>
          </form>
          <div class="ms-slidebar-t">
            <span class="ms-logo ms-logo-sm">M</span>
            <h3>Material
              <span>Style</span>
            </h3>
          </div>
        </div>
      </header>
      <ul class="ms-slidebar-menu" id="slidebar-menu" role="tablist" aria-multiselectable="true">
        <li class="panel" role="tab" id="sch1">
          <a class="collapsed" role="button" data-toggle="collapse" data-parent="#slidebar-menu" href="#sc1" aria-expanded="false" aria-controls="sc1">
            <i class="zmdi zmdi-home"></i> Home </a>
          <ul id="sc1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="sch1">
            <li>
              <a href="index-2.html">Default Home</a>
            </li>
            <li>
              <a href="home-generic-2.html">Home Black Slider</a>
            </li>
            <li>
              <a href="home-landing.html">Home Landing Intro</a>
            </li>
            <li>
              <a href="home-landing3.html">Home Landing Video</a>
            </li>
            <li>
              <a href="home-shop.html">Home Shop 1</a>
            </li>
          </ul>
        </li>
        <li class="panel" role="tab" id="sch2">
          <a class="collapsed" role="button" data-toggle="collapse" data-parent="#slidebar-menu" href="#sc2" aria-expanded="false" aria-controls="sc2">
            <i class="zmdi zmdi-desktop-mac"></i> Pages </a>
          <ul id="sc2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="sch2">
            <li>
              <a href="page-about.html">About US</a>
            </li>
            <li>
              <a href="page-team.html">Our Team</a>
            </li>
            <li>
              <a href="page-product.html">Products</a>
            </li>
            <li>
              <a href="page-services.html">Services</a>
            </li>
            <li>
              <a href="page-faq.html">FAQ</a>
            </li>
            <li>
              <a href="page-timeline_left.html">Timeline</a>
            </li>
            <li>
              <a href="page-contact.html">Contact Option</a>
            </li>
            <li>
              <a href="page-login.html">Login</a>
            </li>
            <li>
              <a href="page-pricing.html">Pricing</a>
            </li>
            <li>
              <a href="page-coming.html">Coming Soon</a>
            </li>
          </ul>
        </li>
        <li class="panel" role="tab" id="sch4">
          <a class="collapsed" role="button" data-toggle="collapse" data-parent="#slidebar-menu" href="#sc4" aria-expanded="false" aria-controls="sc4">
            <i class="zmdi zmdi-edit"></i> Blog </a>
          <ul id="sc4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="sch4">
            <li>
              <a href="blog-sidebar.html">Blog Sidebar 1</a>
            </li>
            <li>
              <a href="blog-sidebar2.html">Blog Sidebar 2</a>
            </li>
            <li>
              <a href="blog-masonry.html">Blog Masonry 1</a>
            </li>
            <li>
              <a href="blog-masonry2.html">Blog Masonry 2</a>
            </li>
            <li>
              <a href="blog-full.html">Blog Full Page 1</a>
            </li>
            <li>
              <a href="blog-full2.html">Blog Full Page 2</a>
            </li>
            <li>
              <a href="blog-post.html">Blog Post 1</a>
            </li>
            <li>
              <a href="blog-post2.html">Blog Post 2</a>
            </li>
          </ul>
        </li>
        <li class="panel" role="tab" id="sch5">
          <a class="collapsed" role="button" data-toggle="collapse" data-parent="#slidebar-menu" href="#sc5" aria-expanded="false" aria-controls="sc5">
            <i class="zmdi zmdi-shopping-basket"></i> E-Commerce </a>
          <ul id="sc5" class="panel-collapse collapse" role="tabpanel" aria-labelledby="sch5">
            <li>
              <a href="ecommerce-filters.html">E-Commerce Sidebar</a>
            </li>
            <li>
              <a href="ecommerce-filters-full.html">E-Commerce Sidebar Full</a>
            </li>
            <li>
              <a href="ecommerce-filters-full2.html">E-Commerce Topbar Full</a>
            </li>
            <li>
              <a href="ecommerce-item.html">E-Commerce Item</a>
            </li>
            <li>
              <a href="ecommerce-cart.html">E-Commerce Cart</a>
            </li>
          </ul>
        </li>
        <li class="panel" role="tab" id="sch6">
          <a class="collapsed" role="button" data-toggle="collapse" data-parent="#slidebar-menu" href="#sc6" aria-expanded="false" aria-controls="sc6">
            <i class="zmdi zmdi-collection-image-o"></i> Portfolio </a>
          <ul id="sc6" class="panel-collapse collapse" role="tabpanel" aria-labelledby="sch6">
            <li>
              <a href="portfolio-filters_sidebar.html">Portfolio Sidebar Filters</a>
            </li>
            <li>
              <a href="portfolio-filters_topbar.html">Portfolio Topbar Filters</a>
            </li>
            <li>
              <a href="portfolio-filters_sidebar_fluid.html">Portfolio Sidebar Fluid</a>
            </li>
            <li>
              <a href="portfolio-filters_topbar_fluid.html">Portfolio Topbar Fluid</a>
            </li>
            <li>
              <a href="portfolio-cards.html">Porfolio Cards</a>
            </li>
            <li>
              <a href="portfolio-masonry.html">Porfolio Masonry</a>
            </li>
            <li>
              <a href="portfolio-item.html">Portfolio Item 1</a>
            </li>
            <li>
              <a href="portfolio-item2.html">Portfolio Item 2</a>
            </li>
          </ul>
        </li>
        <li>
          <a class="link" href="component-typography.html">
            <i class="zmdi zmdi-view-compact"></i> UI Elements</a>
        </li>
        <li>
          <a class="link" href="page-all.html">
            <i class="zmdi zmdi-link"></i> All Pages</a>
        </li>
      </ul>
      <div class="ms-slidebar-social ms-slidebar-block">
        <h4 class="ms-slidebar-block-title">Social Links</h4>
        <div class="ms-slidebar-social">
          <a href="javascript:void(0)" class="btn-circle btn-circle-raised btn-facebook">
            <i class="zmdi zmdi-facebook"></i>
            <span class="badge badge-pink">12</span>
            <div class="ripple-container"></div>
          </a>
          <a href="javascript:void(0)" class="btn-circle btn-circle-raised btn-twitter">
            <i class="zmdi zmdi-twitter"></i>
            <span class="badge badge-pink">4</span>
            <div class="ripple-container"></div>
          </a>
          <a href="javascript:void(0)" class="btn-circle btn-circle-raised btn-google">
            <i class="zmdi zmdi-google"></i>
            <div class="ripple-container"></div>
          </a>
          <a href="javascript:void(0)" class="btn-circle btn-circle-raised btn-instagram">
            <i class="zmdi zmdi-instagram"></i>
            <div class="ripple-container"></div>
          </a>
        </div>
      </div>
    </div>
@endsection
