@extends('layouts.front')
@section('content')
    <div class="container " >
        <div class="row" style=" ">
            <div class="col-md-12 text-justify">
<div class="panel panel-primary">
    <div class="panel-heading">
        <h2 class="panel-title">STATEMENT BY HAPPY WORLD MEAL GATE TO CAUTION MEMBERS ON THE NEED TO
            AVOID CONTRAVENING THE MARKETING AND COMPENSATION
            PLAN</h2>
    </div>
    <div class="panel-body">
<p>The Management of Happy World Meal Gate (HWMG) Limited has received several complaints from members who have claimed they have been required to part with huge amounts of money by other members as a part of an investment and by which they have been assured they would achieve certain milestones or stages in the Compensation Plan of Happy World.</p>
        <p>For the avoidance of doubt, the Happy World Marketing Plan has advised prospective registrants to open 1, 3 or where the intending member has the capacity; a maximum of 7 accounts which at the most cannot and must not cost the registrant more than N44,800.00.</p>
        <p>It should be emphasized that it is the active effort by a member essentially to replicate himself/herself by the addition of a new member as a downline on both sides of his/her matrix (legs) that creates the upward push or achievement of stages.</p>
        <p>The Management has not advertised, condoned, consented to or authorized any arrangement, scheme or investment that is not in compliance with its very open and easy to follow Compensation Plan and accordingly will not be liable or responsible for any consequence that arises out of a departure from it.</p>
        <p>The Management further wishes to restate that the unit cost of Registration on the Platform is N6,400.00 which is the amount that is arrived at using Happy World ‘s unique rate of conversion from $32 at N200.00 to $1.No member is expected to either pay less or pay more than this stipulated rate and there are on-going efforts to trace the source and personalities involved in selling the Pins for more or less than this amount. Where a person is confirmed to be involved in this unauthorized act, such a person will be blacklisted and evicted from the Platform for attempting to compromise the integrity of Happy World.</p></div>
</div>
            </div>
        </div>
    </div>
    @endsection