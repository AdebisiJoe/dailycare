@extends('website4.layouts.front')
@section('content')

    <div class="ms-hero ms-hero-material" style="
    height: 558px;
    padding-top: 11%;
    padding-bottom: 29%;
    /*background-image: url('../image/img.jpg');*/
    background-size: cover;
    background-repeat: no-repeat;
    ">
        <span class="ms-hero-bg"></span>
        <div class="container"  style="
   display: block;
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    width: 100%;
    height: 100%;
    z-index: 2;
        background-color: rgba(0,0,0,.4);
">
            <div class="row">

                <div id="carousel-header" class="carousel carousel-header slide" data-ride="carousel" data-interval="5000" style="
                     padding-top: 10%;">
                         <!-- Indicators -->
                    <!-- Wrapper for slides -->
                    <div class="ms-hero-material-title animated slideInLeft animation-delay-5">
                    <div class="carousel-inner" role="listbox">
                        <div class="item active">
                            <div class="container" >
                                <div class="row">
                                    <div class="col-lg-6 col-md7">
                                        <div class="carousel-caption">
                                            <h1 class=" no-mt mb-4" style="text-shadow: none;"><span class="color-primary"  style=" font-weight: 100;
                 font-size: 45px;
          line-height: 55px;">Happy World Meal Gate </span><br> <strong style=" font-weight: 300;">Is The Solution To</strong></h1>
                                            <p style="font-size: 18px; font-size: 18px; text-align: justify; text-shadow: none;">
                                              Increasing food prices, loss of jobs, decreasing income & hunger in Africa.
                                                <br>We are proffering a sustainable food/reward system for everyone.

                                            </p>
                                            <div >
                                                <a href="/join-now" class="btn btn-homepage-join btn-primary btn-xlg btn-raised animated flipInX ">
                                                    <i class="zmdi zmdi-settings"></i> Join Now</a>
                                               <!--  <a href="#" class="btn btn-homepage-see btn-warning btn-xlg btn-raised animated flipInX ">
                                                    <i class="zmdi zmdi-download"></i> See How</a> -->
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md7" style="margin-top: -5%;">
                                        <img src="{{ URL::to('/') }}/public/assets/website4/sliders/c.png" alt="..." class="img-responsive mt-6 center-block text-center animated zoomInDown animation-delay-5"> </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                    <!-- Controls -->
                        <a href="#carousel-header" class="btn-circle btn-circle-xs btn-circle-raised btn-circle-primary left carousel-control" role="button" data-slide="prev">
                          <i class="zmdi zmdi-chevron-left"></i>
                        </a>
                        <a href="#carousel-header" class="btn-circle btn-circle-xs btn-circle-raised btn-circle-primary right carousel-control" role="button" data-slide="next">
                          <i class="zmdi zmdi-chevron-right"></i>
                        </a>
                </div>
            </div>
        </div>
    </div>

<!-- <div class="container">
  <section class="mb-4">
    <h2 class="text-center no-mt mb-6 wow fadeInUp">Our Services</h2>
    <div class="row">
      <div class="col-md-4 col-sm-6 mb-2">
        <div class="ms-icon-feature wow flipInX animation-delay-4">
          <div class="ms-icon-feature-icon">
            <span class="ms-icon ms-icon-lg ms-icon-inverse">
              <i class="fa fa-cloud"></i>
            </span>
          </div>
          <div class="ms-icon-feature-content">
            <h4 class="color-primary">Cloud Computing</h4>
            <p>Praesentium cumque voluptate harum quae doloribus, atque error debitis, amet velit in similique, necessitatibus odit vero sunt.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4 col-sm-6 mb-2">
        <div class="ms-icon-feature wow flipInX animation-delay-4">
          <div class="ms-icon-feature-icon">
            <span class="ms-icon ms-icon-lg ms-icon-inverse">
              <i class="fa fa-desktop"></i>
            </span>
          </div>
          <div class="ms-icon-feature-content">
            <h4 class="color-primary">Web Design and SEO</h4>
            <p>Praesentium cumque voluptate harum quae doloribus, atque error debitis, amet velit in similique, necessitatibus odit vero sunt.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4 col-sm-6 mb-2">
        <div class="ms-icon-feature wow flipInX animation-delay-4">
          <div class="ms-icon-feature-icon">
            <span class="ms-icon ms-icon-lg ms-icon-inverse">
              <i class="fa fa-tablet"></i>
            </span>
          </div>
          <div class="ms-icon-feature-content">
            <h4 class="color-primary">Mobile and Tablet Apps</h4>
            <p>Praesentium cumque voluptate harum quae doloribus, atque error debitis, amet velit in similique, necessitatibus odit vero sunt.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4 col-sm-6 mb-2">
        <div class="ms-icon-feature wow flipInX animation-delay-4">
          <div class="ms-icon-feature-icon">
            <span class="ms-icon ms-icon-lg ms-icon-inverse">
              <i class="fa fa-wordpress"></i>
            </span>
          </div>
          <div class="ms-icon-feature-content">
            <h4 class="color-primary">Wordpress Themes</h4>
            <p>Praesentium cumque voluptate harum quae doloribus, atque error debitis, amet velit in similique, necessitatibus odit vero sunt.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4 col-sm-6 mb-2">
        <div class="ms-icon-feature wow flipInX animation-delay-4">
          <div class="ms-icon-feature-icon">
            <span class="ms-icon ms-icon-lg ms-icon-inverse">
              <i class="fa fa-graduation-cap"></i>
            </span>
          </div>
          <div class="ms-icon-feature-content">
            <h4 class="color-primary">Training and development</h4>
            <p>Praesentium cumque voluptate harum quae doloribus, atque error debitis, amet velit in similique, necessitatibus odit vero sunt.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4 col-sm-6 mb-2">
        <div class="ms-icon-feature wow flipInX animation-delay-4">
          <div class="ms-icon-feature-icon">
            <span class="ms-icon ms-icon-lg ms-icon-inverse">
              <i class="fa fa-send"></i>
            </span>
          </div>
          <div class="ms-icon-feature-content">
            <h4 class="color-primary">Customer service</h4>
            <p>Praesentium cumque voluptate harum quae doloribus, atque error debitis, amet velit in similique, necessitatibus odit vero sunt.</p>
          </div>
        </div>
      </div>
    </div>
  </section>
</div> -->

<div class="container wow fadeInUp" >
    <div class="row" style=" ">
        <div class="col-md-6 text-justify">
            <h2 class=" right-line">Welcome <span style="color: #ffcc33">Message</span></h2>
            <p>Hello Friend,
Welcome to the official website of the Community of Happy People!
Happy World Meal Gate was borne out of a deep-seated desire to bring lasting succor and much-needed food security in Nigeria and Africa.
      </p>
            <p>We are family/community centered and passionate about the overall wellbeing of Africans. Led doggedly by our firm belief in people as our greatest resource, We set sail in October 2016 to ensure the provision of food and standard nutrition for all.
It gladdens my heart that our impact reverberates not only in Nigeria but also on the continent. We are currently adjudged one of the fastest-rising network marketing companies and our food security initiative is second to none.</p><p>
We are presently in several states in Nigeria in addition to several countries spread across Africa.
Our watchword is hinged on integrity and service; laced with a strong corporate governance culture. A combination of these elements, provides the requisite fuel to ensure world class standards and top notch service delivery.
As our success partner, expect a retinue of life-improving value added services and bespoke benefits tailored specially for you.
Remember: Happiness is not only a state of mind, it is a lifestyle!
Join Us as We daily say NO TO HUNGER & MALNUTRITION!!
See you at the top.



      </p>
            <p class="text-right">
                Your Success Partner,<br>
                <cite class="lead color "> — <span class="color-primary">SY Lento,</span> MD/CEO Happy World Meal Gate.</cite>
            </p>
        </div>
        <div class="col-md-6">
            <h2 class="right-line">Our <span style="color: #ffcc33">Approach</span></h2>
            <div class="panel-group ms-collapse" id="accordion" role="tablist" aria-multiselectable="true">
                <div class="panel panel-primary">
                    <div class="panel-heading" role="tab" id="headingOne">
                        <h4 class="panel-title">
                            <a class="withripple" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                <i class="fa fa-globe" style="color: #00bcd4!important"></i>           Our <span style="color: #00bcd4">Mission</span>
                            </a>
                        </h4>
                    </div>
                    <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                        <div class="panel-body">
                            <p>
                                Good nutrition and food security for all irrespective of income, status, creed or geographical location</p>
                        </div>
                    </div>
                </div>
                <div class="panel panel-primary">
                    <div class="panel-heading" role="tab" id="headingTwo">
                        <h4 class="panel-title">
                            <a class="collapsed withripple" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                <i class="fa fa-eye" style="color: #ff9800!important"></i>Our <span style="color: #ff9800">Vision</span>
                            </a>
                        </h4>
                    </div>
                    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                        <div class="panel-body">
                            <p>
                                To proffer timely, and adaptable solutions to hunger and malnutrition across the African continent and the globe.</p>
                        </div>
                    </div>
                </div>
                <div class="panel panel-primary">
                    <div class="panel-heading" role="tab" id="headingThree">
                        <h4 class="panel-title">
                            <a class="collapsed withripple" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                <i class="fa fa-play" style="color:#4caf50!important "></i> Our <span style="color: #4caf50">Philosophy </span></a>
                        </h4>
                    </div>
                    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                        <div class="panel-body">
                            <p>Happy and Well Fed People are Productive People
                                You have the right not to go to bed hungry</p>
                        </div>
                    </div>
                </div>
                <div class="panel panel-primary">
                    <div class="panel-heading" role="tab" id="headingFour">
                        <h4 class="panel-title">
                            <a class="collapsed withripple" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                <i class="fa fa-heart" style="color: #f44336!important"></i>  Our <span style="color: #f44336">CSR</span>

                            </a>
                        </h4>
                    </div>
                    <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">
                        <div class="panel-body">
                            <p> Happy World Foundation - A movement aimed at eradicating hunger and malnutrition from our society.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="wrap wrap-mountain mt-6">
    <div class="container">
        <h2 class="text-left text-light wow fadeInDown animation-delay-5" style="visibility: visible; animation-name: fadeInDown;">Why join<br>
            <strong style="font-weight: bold !important;" class="color-primary">Happy World Meal Gate ?</strong></h2>
        <div class="row">
            <div class="col-md-6 col-md-push-6 mb-4  center-block">
                <img src="{{ URL::to('/') }}/public/assets/website4/sliders/happy woman.png" alt="" class="img-responsive center-block wow zoomIn animation-delay-12" style="visibility: visible; animation-name: zoomIn;"> </div>
            <div class="col-md-6 col-md-pull-6 pr-6">
                <p  class="wow fadeInLeft animation-delay-6" style="visibility: visible; text-align: justify; animation-name: fadeInLeft;">
                    We are passionate about earth’s greatest resource:PEOPLE.
Where others see challenges,We see solutions.
We are Africa’s fastest-rising food security network.
We are passionate about empowering people to enable them meet their basic need:Food.



                </p>
                <p class="wow fadeInLeft animation-delay-7" style="visibility: visible; text-align: justify; animation-name: fadeInLeft;">We are spearheading the crusade ‘’OPERATION SAY NO TO HUNGER’’ in homes & communities in Nigeria and Africa.
Leveraging on the multi-level marketing platform,together We will defeat hunger/malnutrition and increase disposable income of the lower class of society.</p>
                <p class="wow fadeInLeft animation-delay-8" style="visibility: visible; text-align: justify; animation-name: fadeInLeft;">
                   We believe good nutrition and food security should not be an exclusive preserve of a few.It should be readily available and accessible to everyone; irrespective of creed,status,income or geographical spread.
We wholly concur with the Food & Agricultural Organization (FAO) motto: ‘Fiat Panis’ which means ‘Let there be bread.’</p>
                <div class="text-left">
                    <a href="javascript:void(0)" class="btn btn-warning btn-xlg btn-homepage-join btn-raised mr-1 wow flipInX animation-delay-14" style="visibility: visible; animation-name: flipInX;">
                        <i class="zmdi zmdi-chart-donut"></i> Join Now </a>
                    <a href="{{ url('/') }}/#Compensation" class="btn btn-homepage-see btn-xlg btn-info btn-raised wow flipInX animation-delay-16" style="visibility: visible; animation-name: flipInX;">
                        <i class="zmdi zmdi-case"></i> See How</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- container -->
<!--   <div class="wrap bg-warning color-dark">
    <div class="container">
      <h1 class="color-white text-center mb-4">Some numerical data</h1>
      <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6">
          <div class="card card-royal card-block text-center wow zoomInUp animation-delay-2">
            <h2 class="counter">450</h2>
            <i class="fa fa-4x fa-coffee color-royal"></i>
            <p class="mt-2 no-mb lead small-caps">cups of coffee</p>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
          <div class="card card-success card-block text-center wow zoomInUp animation-delay-5">
            <h2 class="counter">64</h2>
            <i class="fa fa-4x fa-briefcase color-success"></i>
            <p class="mt-2 no-mb lead small-caps">projects done</p>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
          <div class="card card-danger card-block text-center wow zoomInUp animation-delay-4">
            <h2 class="counter">600</h2>
            <i class="fa fa-4x fa-comments-o color-danger"></i>
            <p class="mt-2 no-mb lead small-caps">comments</p>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6">
          <div class="card card-info card-block text-center wow zoomInUp animation-delay-3">
            <h2 class="counter">3500</h2>
            <i class="fa fa-4x fa-group color-info"></i>
            <p class="mt-2 no-mb lead small-caps">happy clients</p>
          </div>
        </div>
      </div>
      <div class="text-center color-white mw-800 center-block mt-4">
        <p class="lead lead-lg">Discover our projects and the rigorous process of creation. Our principles are creativity, design, experience and knowledge. We are backed by 20 years of research.</p>
        <a href="javascript:void(0)" class="btn btn-raised btn-white color-info wow flipInX animation-delay-8">
          <i class="fa fa-space-shuttle"></i> I have a project</a>
      </div>
    </div>
  </div> -->

<div class="container wow fadeInUp mt-6" id="Compensation">
    <div class="row" style="   ">
        <h2 class="right-line">Compensation <span class="color-primary">Plan</span></h2>
        <div class="card card-danger" style="">
            <ul class="nav nav-tabs nav-tabs-transparent indicator-danger nav-tabs-full nav-tabs-4" role="tablist">
                <li role="presentation" class="active"><a class="withoutripple" href="#farmstage" aria-controls="farmstage" role="tab" data-toggle="tab"><i class="zmdi zmdi-home"></i> <span class="hidden-xs"> Farms Stage

</span></a></li>
                <li role="presentation"><a class="withoutripple" href="#stageone" aria-controls="stageone" role="tab" data-toggle="tab"><i class="zmdi zmdi-account"></i> <span class="hidden-xs"> Stage One</span></a></li>
                <li role="presentation"><a class="withoutripple" href="#stagetwo" aria-controls="stagetwo" role="tab" data-toggle="tab"><i class="zmdi zmdi-email"></i> <span class="hidden-xs"> Stage Two</span></a></li>
                <li role="presentation"><a class="withoutripple" href="#stagethree" aria-controls="stagethree" role="tab" data-toggle="tab"><i class="zmdi zmdi-settings"></i> <span class="hidden-xs"> Stage Three</span></a></li>
                <li role="presentation"><a class="withoutripple" href="#stagefour" aria-controls="stagefour" role="tab" data-toggle="tab"><i class="zmdi zmdi-settings"></i> <span class="hidden-xs"> Stage Four</span></a></li>
                <li role="presentation"><a class="withoutripple" href="#stagefive" aria-controls="stagefive" role="tab" data-toggle="tab"><i class="zmdi zmdi-settings"></i> <span class="hidden-xs"> Stage Five</span></a></li>
            </ul>

            <div class="card-block">
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane fade active in" id="farmstage">
                        <div class="row">
                            <div class="col-md-6 col-md-push-6">
                                <img src="{{ URL::to('/') }}/public/assets/website4/front/img/farm.jpg" alt="" class="img-responsive animated zoomIn animation-delay-8">
                            </div>
                            <div class="col-md-6 col-md-pull-6">
                                <h3 class="text-normal">Farms Stage <small> - Registration</small></h3>
                                <p class="lead lead-md">
                                    At Stage 1, all rewards are in FOOD ITEMS via the concept of ‘Feed yourself and help feed others’.
                                </p>
                                <p class="lead lead-md">
                                </p><ul style="list-style-type: none;">

                                    <li><i class="fa fa-chevron-right"></i>&nbsp; Referral Bonus: $6.4</li>

                                    <li><i class="fa fa-chevron-right"></i>&nbsp; Level Bonus (LB):$38.4</li>

                                    <li><i class="fa fa-chevron-right"></i>&nbsp; Complete Stage (CS):$16.</li>
                                </ul>

                                <strong>NB: Payments at FARMS STAGE are in FOOD ITEMS..</strong>
                                <p></p>

                                <div class="">

                                    <a href="javascript:void(0)" class="btn btn-danger btn-homepage-join btn-raised mr-1 animated zoomIn animation-delay-12">
                                        <i class="zmdi zmdi-account-add"></i> Join Now </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="stageone">
                        <div class="row">
                            <div class="col-md-6">
                                <img src="{{ URL::to('/') }}/public/assets/website4/front/img/greengarden.jpg" alt="" class="img-responsive animated zoomIn animation-delay-8"> </div>
                            <div class="col-md-6">
                                <h3 class="text-normal">Green Garden</h3>
                                <p class="lead lead-md">
                                    At Stage 1, all rewards are in FOOD ITEMS via the concept of ‘Feed yourself and help feed others’.
                                </p>
                                <p class="lead lead-md">
                                </p><ul style="list-style-type: none;">
                                    <li><i class="fa fa-chevron-right"></i>&nbsp; Referral Bonus: $6.4</li>

                                    <li><i class="fa fa-chevron-right"></i>&nbsp; Level Bonus (LB):$224</li>

                                    <li><i class="fa fa-chevron-right"></i>&nbsp; Complete Stage (CS):$160.</li>
                                </ul>

                                <strong>NB: Payments at this stage are in FOOD ITEMS.</strong>
                                <p></p>
                                <div class="">

                                    <a href="javascript:void(0)" class="btn btn-danger btn-homepage-join btn-raised mr-1 ">
                                        <i class="zmdi zmdi-account-add"></i> Join Now </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="stagetwo">
                        <div class="row">
                            <div class="col-md-6 col-md-push-6">
                                <img src="{{ URL::to('/') }}/public/assets/website4/front/img/goldengarden.jpg" alt="" class="img-responsive animated zoomIn animation-delay-8"> </div>
                            <div class="col-md-6 col-md-pull-6">
                                <h3 class="text-normal">Golden Garden</h3>
                                <p class="lead lead-md">Free food items worth $150 for Seven (7) months.</p>
                                <p class="lead lead-md animated fadeInUp animation-delay-7">
                                </p><ul style="list-style-type: none;">
                                    <li><i class="fa fa-chevron-right"></i>&nbsp; Referral Bonus: $6.4</li>

                                    <li><i class="fa fa-chevron-right"></i>&nbsp; Level Bonus (LB):$560</li>

                                    <li><i class="fa fa-chevron-right"></i>&nbsp; Complete Stage (CS):$360.</li>
                                </ul>

                                <strong>NB: Payment is 40% food items and 60% cash.</strong>
                                <p></p>
                                <div class="">

                                    <a href="javascript:void(0)" class="btn btn-danger btn-homepage-join btn-raised mr-1 animated zoomIn animation-delay-12">
                                        <i class="zmdi zmdi-account-add"></i> Join Now </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="stagethree">
                        <div class="row">
                            <div class="col-md-6">
                                <img src="{{ URL::to('/') }}/public/assets/website4/front/img/greatgarden.jpg" alt="" class="img-responsive animated zoomIn animation-delay-8"> </div>
                            <div class="col-md-6">
                                <h3 class="text-normal">Great Garden</h3>
                                <p class="lead lead-md">40% food items and 60% cash. Free trip to Saudi Arabia for Hajj or Umrah (Lesser Hajj) or free trip to Israel or Dubai. All expenses paid inclusive of $5,000 Travelling Allowance.</p>
                                <p class="lead lead-md">
                                </p><ul style="list-style-type: none;">
                                    <li><i class="fa fa-chevron-right"></i>&nbsp; Referral Bonus: $6.4</li>

                                    <li><i class="fa fa-chevron-right"></i>&nbsp; Level Bonus (LB):$700</li>

                                    <li><i class="fa fa-chevron-right"></i>&nbsp; Complete Stage (CS):$3,500.</li>

                                    <li><i class="fa fa-chevron-right"></i>&nbsp; A brand new car worth $22,000.</li>

                                </ul>

                                <strong>NB: Payment is 40% food items and 60% cash.</strong>
                                <p></p>
                                <div class="">

                                    <a href="javascript:void(0)" class="btn btn-danger btn-homepage-join btn-raised mr-1 animated zoomIn animation-delay-12">
                                        <i class="zmdi zmdi-account-add"></i> Join Now </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="stagefour">
                        <div class="row">
                            <div class="col-md-6 col-md-push-6">
                                <img src="{{ URL::to('/') }}/public/assets/website4/front/img/famousfarm.jpg" alt="" class="img-responsive animated zoomIn animation-delay-8"> </div>
                            <div class="col-md-6 col-md-pull-6">
                                <h3 class="text-normal ">Famous Farm </h3>
                                <p class="lead lead-md">
                                    Members at this level will receive 40% food items and 60% cash. They will also be entitled to $250 worth of food items for 12 months.Moreso, a GRAND AWARD of a SUV worth $30,000 will be added to the package.
                                </p>
                                <p class="lead lead-md">
                                </p><ul style="list-style-type: none;">
                                    <li><i class="fa fa-chevron-right"></i>&nbsp; Referral Bonus: $6.4</li>

                                    <li><i class="fa fa-chevron-right"></i>&nbsp; Level Bonus (LB):$2,240</li>

                                    <li><i class="fa fa-chevron-right"></i>&nbsp; Complete Stage (CS):$5,000.</li>

                                    <li><i class="fa fa-chevron-right"></i>&nbsp; A brand new car worth $30,000.</li>

                                </ul>

                                <strong>NB: Payment is 40% food items and 60% cash.</strong>
                                <p></p>
                                <div class="">

                                    <a href="javascript:void(0)" class="btn btn-danger btn-homepage-join btn-raised mr-1 animated zoomIn animation-delay-12">
                                        <i class="zmdi zmdi-account-add"></i> Join Now </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="stagefive">
                        <div class="row">
                            <div class="col-md-6 col-md-push-6">
                                <img src="{{ URL::to('/') }}/public/assets/website4/front/img/foodbank.jpg" alt="" class="img-responsive animated zoomIn animation-delay-8"> </div>
                            <div class="col-md-6 col-md-pull-6">
                                <h3 class="text-normal ">Food Bank</h3>
                                <p class="lead lead-md">At this final stage, you live to earn $6,000 from every team member that joins you. You’re also entitled to the unique privilege of profit sharing from the company.</p>
                                <p class="lead lead-md"><strong>NB: Payment is 40% food items and 60% cash.</strong></p>
                                <div class="">

                                    <a href="javascript:void(0)" class="btn btn-danger btn-homepage-join btn-raised mr-1 animated zoomIn animation-delay-12">
                                        <i class="zmdi zmdi-account-add"></i> Join Now </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




 <div class="mt-4 wow fadeInUp">
          <div class="">
            <h3 class="text-center fw-500 mb-4">Testimonies</h3>
            <div class="mw-800 center-block">
              <div id="carousel-example-generic" class="carousel-cards carousel slide" data-ride="carousel">
                <div class="carousel-inner" role="listbox">
                  <div class="item active">
                    <blockquote class="ms-blockquote">
                      <p class="lead">Happy World is pioneering the campaign against hunger & malnutrition in Nigeria and Africa via network marketing.This crusade is total and on course.Our hands are on the plough…no turning back!</p>
                      <footer>
                        <strong>-SY Lento</strong>,
                        <cite title="Source Title">MD/CEO</cite>
                      </footer>
                    </blockquote>
                  </div>
                  <div class="item">
                    <blockquote class="ms-blockquote">
                      <p class="lead">Happy World Meal Gate is real.It is unlike any other network business out there.Prior to this time,people found it difficult to feed.But with this platform,people now have food and money in their account.It is truly a great place to be.  </p>
                      <footer>
                        <strong> –Jude Ibe </strong>,
                        <cite title="Source Title">Member</cite>
                      </footer>
                    </blockquote>
                  </div>
                  <div class="item">
                    <blockquote class="ms-blockquote">
                      <p class="lead">For those who are yet to join, it is important you hasten up and join now. Once you come onboard, your pocket will be filled, your family and community will no longer know hunger and you will touch lives. Happy World is the best.<br>
                                               </p>
                      <footer>
                        <strong>-Nelly Edozie</strong>,
                        <cite title="Source Title"> Member</cite>
                      </footer>
                    </blockquote>
                  </div>
                </div>
                <ol class="carousel-indicators carousel-indicators-primary">
                  <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                  <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                  <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                </ol>
              </div>
            </div>
          </div>
        </div>

<div class="wrap wrap-mountain" style="
    padding-bottom: 0% !important;
    padding-top: 0%!important;
">
    <div class="container">
        <h2 class="text-left text-light wow fadeInDown animation-delay-5" style="visibility: visible; animation-name: fadeInDown;">Our<br>
            <strong style="font-weight: bold !important;" class="color-primary">Social Media Feeds</strong></h2>
        <div class="row">
            <div class="col-md-4 col-sm-6 mb-4">
             <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fhappyworldmealgate&tabs=timeline&width=600&height=500&small_header=true&adapt_container_width=false&hide_cover=false&show_facepile=false&appId" width="600" height="300" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
            </div>

            <div class="col-md-2"></div>
            <div class="col-md-4 col-sm-6 mb-4  pr-6 animation-delay-8 ow fadeInLeft " style="width: 580px;">
               <a class="twitter-timeline" data-width="800" data-height="300" href="https://twitter.com/HappyWorldMeal?ref_src=twsrc%5Etfw">Tweets by HappyWorldMeal</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
            </div>
        </div>
    </div>
</div>

<section>
    <div class="container">
        <div class="row">

    </div>


    </div>
    </div>
</section>
<!-- <section class="mt-6">
    <div class="container">
        <h2 class="right-line">Latest <span class="color-primary">Posts</span></h2>
        <div class="row">
            <div class="col-md-4 col-sm-6 mb-4">
                <div class="ms-thumbnail-container wow fadeInUp">
                    <figure class="ms-thumbnail">
                        <img src="../front/img/demo/port9.jpg" alt="" class="img-responsive">
                        <figcaption class="ms-thumbnail-caption text-center">
                            <div class="ms-thumbnail-caption-content">
                                <h3 class="ms-thumbnail-caption-title">Lorem ipsum dolor sit</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                                <a href="javascript:void(0)" class="btn btn-white btn-raised color-primary">
                                    <i class="zmdi zmdi-eye"></i> View more</a>
                            </div>
                        </figcaption>
                    </figure>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 mb-4">
                <div class="ms-thumbnail-container wow fadeInUp">
                    <figure class="ms-thumbnail">
                        <img src="../front/img/demo/port11.jpg" alt="" class="img-responsive">
                        <figcaption class="ms-thumbnail-caption text-center">
                            <div class="ms-thumbnail-caption-content">
                                <h3 class="ms-thumbnail-caption-title">Lorem ipsum dolor sit</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                                <a href="javascript:void(0)" class="btn btn-white btn-raised color-primary">
                                    <i class="zmdi zmdi-eye"></i> View more</a>
                            </div>
                        </figcaption>
                    </figure>
                </div>
            </div>
            <div class="col-md-4 col-sm-6 mb-4">
                <div class="ms-thumbnail-container wow fadeInUp">
                    <figure class="ms-thumbnail">
                        <img src="../front/img/demo/port23.jpg" alt="" class="img-responsive">
                        <figcaption class="ms-thumbnail-caption text-center">
                            <div class="ms-thumbnail-caption-content">
                                <h3 class="ms-thumbnail-caption-title">Lorem ipsum dolor sit</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
                                <a href="javascript:void(0)" class="btn btn-white btn-raised color-primary">
                                    <i class="zmdi zmdi-eye"></i> View more</a>
                            </div>
                        </figcaption>
                    </figure>
                </div>
            </div>

        </div>
    </div>
</section> -->


@endsection
